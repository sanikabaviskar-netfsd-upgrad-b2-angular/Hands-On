Week-11 Day-2 Angular Contact App

This is a full Angular CLI-style project for VS Code.

Covers all 3 problems:

Problem 1 - Angular Routing
- /contacts
- /add-contact
- /contact/:id
- routerLink
- Router navigation
- ActivatedRoute

Problem 2 - Route Guard
- AuthGuard
- canActivate
- simulated login/logout using AuthService
- /add-contact and /contact/:id protected
- /contacts public

Problem 3 - Angular Service + Dependency Injection
- ContactService
- getContacts()
- addContact()
- getContactById()
- injected into components

How to run:

1. Extract zip
2. Open folder in VS Code
3. Run:
   npm install
   npm start

Then open:
http://localhost:4200

Important behavior:
- Contact list is public
- Add Contact and Contact Details require login
- Click Login button before accessing protected routes
