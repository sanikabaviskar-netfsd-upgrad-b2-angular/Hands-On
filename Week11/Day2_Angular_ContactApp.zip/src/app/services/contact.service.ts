import { Injectable } from '@angular/core';
import { Contact } from '../models/contact.model';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private contacts: Contact[] = [
    { id: 1, name: 'Rahul Sharma', email: 'rahul@example.com', phone: '9876543210' },
    { id: 2, name: 'Aisha Khan', email: 'aisha@example.com', phone: '9123456780' }
  ];

  getContacts(): Contact[] {
    return this.contacts;
  }

  getContactById(id: number): Contact | undefined {
    return this.contacts.find(contact => contact.id === id);
  }

  addContact(contact: Omit<Contact, 'id'>): void {
    const nextId = this.contacts.length === 0
      ? 1
      : Math.max(...this.contacts.map(contactItem => contactItem.id)) + 1;

    this.contacts.push({
      id: nextId,
      ...contact
    });
  }
}
