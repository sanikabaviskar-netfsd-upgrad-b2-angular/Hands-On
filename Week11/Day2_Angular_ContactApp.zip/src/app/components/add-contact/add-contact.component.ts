import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ContactService } from '../../services/contact.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html'
})
export class AddContactComponent {
  name = '';
  email = '';
  phone = '';

  constructor(
    private contactService: ContactService,
    private router: Router
  ) {}

  addContact(): void {
    if (!this.name || !this.email || !this.phone) {
      alert('Please enter all contact details.');
      return;
    }

    this.contactService.addContact({
      name: this.name,
      email: this.email,
      phone: this.phone
    });

    this.router.navigate(['/contacts']);
  }
}
