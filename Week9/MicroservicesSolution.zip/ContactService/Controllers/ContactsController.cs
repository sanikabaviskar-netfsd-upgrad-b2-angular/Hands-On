
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class ContactsController : ControllerBase
{
    static List<object> contacts = new();

    [HttpGet]
    public IActionResult Get() => Ok(contacts);

    [HttpPost]
    public IActionResult Post(object c)
    {
        contacts.Add(c);
        return Ok(c);
    }
}
