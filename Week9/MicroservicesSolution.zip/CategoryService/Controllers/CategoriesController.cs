
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class CategoriesController : ControllerBase
{
    static List<object> categories = new();

    [HttpGet]
    public IActionResult Get() => Ok(categories);

    [HttpPost]
    public IActionResult Post(object c)
    {
        categories.Add(c);
        return Ok(c);
    }
}
