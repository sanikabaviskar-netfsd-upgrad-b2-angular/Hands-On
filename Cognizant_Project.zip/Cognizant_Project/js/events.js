
if (localStorage.getItem("isLoggedIn") !== "true") {
    alert("Please login first");
    window.location.href = "login.html";
}

window.onload = function () {

    let logoutBtn = document.getElementById("logoutItem");

    if (logoutBtn) {
        logoutBtn.style.display = "block"; // user already logged in
    }

    document.getElementById("eventForm").addEventListener("submit", saveEvent);
};


let db;

let request = indexedDB.open("EventDB", 1);


request.onupgradeneeded = function (e) {
    db = e.target.result;

    if (!db.objectStoreNames.contains("events")) {
        let store = db.createObjectStore("events", { keyPath: "id" });

        store.add({
            id: 101,
            name: "Tech Conference",
            category: "Tech & Innovations",
            date: "2026-03-15",
            time: "10:00",
            url: "https://example.com/tech"
        });

        store.add({
            id: 102,
            name: "Industrial Summit",
            category: "Industrial Event",
            date: "2026-03-17",
            time: "15:00",
            url: "https://example.com/industrial"
        });
    }
};

request.onsuccess = function (e) {
    db = e.target.result;
    displayEvents();
};


request.onerror = function () {
    console.log("Database error");
};

function saveEvent(e) {

    e.preventDefault();

    let id = Number(document.getElementById("eventId").value);
    let name = document.getElementById("eventName").value.trim();
    let category = document.getElementById("category").value;
    let date = document.getElementById("date").value;
    let time = document.getElementById("time").value;
    let url = document.getElementById("url").value.trim();

    if (!id || !name || !category || !date || !time || !url) {
        alert("Please fill all fields");
        return;
    }

    let tx = db.transaction("events", "readwrite");
    let store = tx.objectStore("events");

    let check = store.get(id);

    check.onsuccess = function () {

        if (check.result) {
            alert("Event ID already exists");
        } else {
            store.add({ id, name, category, date, time, url });

            alert("Event Added");
            document.getElementById("eventForm").reset();

            displayEvents();
        }
    };
}

function displayEvents() {

    let container = document.getElementById("eventContainer");
    container.innerHTML = "";

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    store.openCursor().onsuccess = function (e) {

        let cursor = e.target.result;

        if (cursor) {

            let event = cursor.value;

            let card = `
            <div class="col-md-4">
              <div class="card mb-3 shadow">
                <div class="card-body">

                  <h5>${event.name}</h5>

                  <p><b>ID:</b> ${event.id}</p>
                  <p><b>Category:</b> ${event.category}</p>
                  <p><b>Date:</b> ${event.date}</p>
                  <p><b>Time:</b> ${event.time}</p>

                  <a href="${event.url}" target="_blank"
                  class="btn btn-primary w-100 mb-2">
                  Join Event
                  </a>

                  <button class="btn btn-danger w-100"
                  onclick="deleteEvent(${event.id})">
                  Delete
                  </button>

                </div>
              </div>
            </div>
            `;

            container.innerHTML += card;

            cursor.continue();
        }
    };
}
function deleteEvent(id) {

    let tx = db.transaction("events", "readwrite");
    let store = tx.objectStore("events");

    store.delete(id);

    tx.oncomplete = function () {
        alert("Event Deleted");
        displayEvents();
    };
}

function searchEvent() {

    let keyword = document.getElementById("searchInput").value.toLowerCase().trim();

    if (keyword === "") {
        displayEvents();
        return;
    }

    let container = document.getElementById("eventContainer");
    container.innerHTML = "";

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    store.openCursor().onsuccess = function (e) {

        let cursor = e.target.result;

        if (cursor) {

            let event = cursor.value;

            if (
                event.id.toString().includes(keyword) ||
                event.name.toLowerCase().includes(keyword) ||
                event.category.toLowerCase().includes(keyword)
            ) {

                let card = `
                <div class="col-md-4">
                  <div class="card mb-3 shadow">
                    <div class="card-body">

                      <h5>${event.name}</h5>

                      <p><b>ID:</b> ${event.id}</p>
                      <p><b>Category:</b> ${event.category}</p>
                      <p><b>Date:</b> ${event.date}</p>
                      <p><b>Time:</b> ${event.time}</p>

                    </div>
                  </div>
                </div>
                `;

                container.innerHTML += card;
            }

            cursor.continue();
        }
    };
}

function resetSearch() {
    document.getElementById("searchInput").value = "";
    displayEvents();
}

function logout() {
    localStorage.removeItem("isLoggedIn");
    alert("Logged out successfully");
    window.location.href = "login.html";
}