
window.onload = function () {

    let isLoggedIn = localStorage.getItem("isLoggedIn");
    let logoutBtn = document.getElementById("logoutItem");

    if (logoutBtn) {
        logoutBtn.style.display = (isLoggedIn === "true") ? "block" : "none";
    }
};



const params = new URLSearchParams(window.location.search);
let eventId = Number(params.get("id"));

let db;



let request = indexedDB.open("EventDB", 1);



request.onerror = function () {
    alert("Database error");
};

request.onsuccess = function (e) {

    db = e.target.result;

    if (!eventId) {
        alert("Invalid event");
        window.location.href = "events.html";
        return;
    }

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    let req = store.get(eventId);

    req.onsuccess = function () {

        let event = req.result;

        if (!event) {
            alert("Event not found");
            window.location.href = "events.html";
            return;
        }

        document.getElementById("eventId").innerText = event.id;
        document.getElementById("eventName").innerText = event.name;
        document.getElementById("eventCategory").innerText = event.category;
        document.getElementById("eventDate").innerText = event.date;
        document.getElementById("eventTime").innerText = event.time;
    };
};


document.getElementById("registrationForm").addEventListener("submit", function (e) {

    e.preventDefault();

    let firstName = document.getElementById("firstName").value.trim();
    let lastName = document.getElementById("lastName").value.trim();
    let email = document.getElementById("email").value.trim();

    
    if (!firstName || !lastName || !email) {
        alert("Please fill all fields");
        return;
    }


    alert("You are successfully registered to this event!");

    document.getElementById("registrationForm").reset();
});

function logout() {
    localStorage.removeItem("isLoggedIn");
    alert("Logged out successfully");
    window.location.href = "login.html";
}