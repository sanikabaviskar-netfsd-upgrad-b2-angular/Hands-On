let db;

window.onload = function () {

    let isLoggedIn = localStorage.getItem("isLoggedIn");
    let logoutBtn = document.getElementById("logoutItem");

    if (logoutBtn) {
        logoutBtn.style.display = (isLoggedIn === "true") ? "block" : "none";
    }
};


let request = indexedDB.open("EventDB", 1);


request.onupgradeneeded = function (e) {

    db = e.target.result;

    if (!db.objectStoreNames.contains("events")) {
        db.createObjectStore("events", { keyPath: "id" });
    }
};

request.onsuccess = function (e) {

    db = e.target.result;
    loadEvents();
};

request.onerror = function () {
    alert("Database error");
};


function loadEvents() {

    let container = document.getElementById("eventList");

    if (!container) return;

    container.innerHTML = "";

    let tx = db.transaction("events", "readonly");
    let store = tx.objectStore("events");

    store.openCursor().onsuccess = function (e) {

        let cursor = e.target.result;

        if (cursor) {

            let event = cursor.value;

            let card = `
            <div class="col-md-4 mb-4">

                <div class="card shadow">

                    <div class="card-body">

                        <h5 class="card-title">${event.name}</h5>

                        <p><b>ID:</b> ${event.id}</p>
                        <p><b>Category:</b> ${event.category}</p>
                        <p><b>Date:</b> ${event.date}</p>
                        <p><b>Time:</b> ${event.time}</p>

                        <button class="btn btn-success w-100"
                        onclick="registerEvent(${event.id})">
                        Register
                        </button>

                    </div>

                </div>

            </div>
            `;

            container.innerHTML += card;

            cursor.continue();
        }
    };
}

function registerEvent(id) {

    window.location.href = "register.html?id=" + id;
}

function logout() {

    localStorage.removeItem("isLoggedIn");

    alert("Logged out successfully");

    window.location.href = "login.html";
}