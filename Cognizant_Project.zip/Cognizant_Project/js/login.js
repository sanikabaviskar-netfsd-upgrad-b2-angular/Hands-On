document.getElementById("loginForm").addEventListener("submit", function(e){

e.preventDefault();

let email = document.getElementById("email").value.trim();
let password = document.getElementById("password").value.trim();

if(email === "admin@upgrad.com" && password === "12345"){

alert("Login Successful");


localStorage.setItem("isLoggedIn","true");

window.location.href = "events.html";

}
else{

alert("Invalid Email or Password");

}

});