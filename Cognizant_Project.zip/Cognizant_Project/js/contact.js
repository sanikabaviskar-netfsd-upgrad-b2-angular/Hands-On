
window.onload = function () {

    let isLoggedIn = localStorage.getItem("isLoggedIn");
    let logoutBtn = document.getElementById("logoutItem");

    if (logoutBtn) {
        logoutBtn.style.display = (isLoggedIn === "true") ? "block" : "none";
    }
};

document.getElementById("contactForm").addEventListener("submit", function(e){

    e.preventDefault();

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let description = document.getElementById("description").value.trim();

    if(name === "" || email === "" || description === ""){
        alert("Please fill all fields");
        return;
    }

    if(description.length < 10){
        alert("Description must be at least 10 characters");
        return;
    }

    alert("Your message has been submitted successfully!");

    document.getElementById("contactForm").reset();

});


function logout() {
    localStorage.removeItem("isLoggedIn");
    alert("Logged out successfully");
    window.location.href = "login.html";
}