let contacts = [];

document.addEventListener("DOMContentLoaded", function () {

    const contactForm = document.getElementById("contactForm");
    const contactList = document.getElementById("contactList");

    loadContacts();

    contactForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();

        console.log("Name:", name);
        console.log("Email:", email);

        if (!name || !email) {
            alert("Please fill all fields");
            console.error("Name or Email missing");
            return;
        }

        const newContact = {
            id: Date.now(),
            name,
            email
        };

        contacts.push(newContact);

        renderContacts();
        saveContacts();
        saveContactToAPI(newContact);

        contactForm.reset();
    });

    // Render contacts
    function renderContacts() {
        contactList.innerHTML = "";

        contacts.forEach(contact => {
            const li = document.createElement("li");
            li.innerHTML = `
                <strong>${contact.name}</strong><br>
                ${contact.email}
            `;
            contactList.appendChild(li);
        });
    }

    // Save to localStorage
    function saveContacts() {
        localStorage.setItem("contacts", JSON.stringify(contacts));
    }

    // Load contacts
    function loadContacts() {
        const storedContacts = localStorage.getItem("contacts");

        if (storedContacts) {
            contacts = JSON.parse(storedContacts);
            renderContacts();
        }
    }

    // API integration for debugging Network Tab
    function saveContactToAPI(contact) {
        fetch("https://jsonplaceholder.typicode.com/users", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(contact)
        })
        .then(response => {
            console.log("Status Code:", response.status);
            return response.json();
        })
        .then(data => {
            console.log("API Success:", data);
        })
        .catch(error => {
            console.error("API Error:", error);
        });
    }

});